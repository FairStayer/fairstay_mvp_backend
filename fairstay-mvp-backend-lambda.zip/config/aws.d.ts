import AWS from 'aws-sdk';
export declare const s3: AWS.S3;
export declare const dynamoDB: AWS.DynamoDB;
export declare const documentClient: AWS.DynamoDB.DocumentClient;
export { AWS };
//# sourceMappingURL=aws.d.ts.map