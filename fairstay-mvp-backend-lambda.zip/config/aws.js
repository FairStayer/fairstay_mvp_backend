"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AWS = exports.documentClient = exports.dynamoDB = exports.s3 = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
exports.AWS = aws_sdk_1.default;
// AWS SDK 설정
aws_sdk_1.default.config.update({
    region: process.env.AWS_REGION || 'ap-northeast-2',
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});
exports.s3 = new aws_sdk_1.default.S3({
    apiVersion: '2006-03-01',
    region: process.env.S3_REGION || process.env.AWS_REGION,
});
exports.dynamoDB = new aws_sdk_1.default.DynamoDB({
    apiVersion: '2012-08-10',
    region: process.env.AWS_REGION || 'ap-northeast-2',
});
exports.documentClient = new aws_sdk_1.default.DynamoDB.DocumentClient({
    service: exports.dynamoDB,
    convertEmptyValues: true,
});
//# sourceMappingURL=aws.js.map