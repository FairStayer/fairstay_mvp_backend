export declare const TABLES: {
    SESSIONS: string;
    IMAGES: string;
    SURVEY_RESPONSES: string;
};
export declare const createTablesIfNotExists: () => Promise<void>;
export declare const connectDB: () => Promise<void>;
//# sourceMappingURL=database.d.ts.map