"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.connectDB = exports.createTablesIfNotExists = exports.TABLES = void 0;
const aws_1 = require("./aws");
// DynamoDB 테이블 이름
exports.TABLES = {
    SESSIONS: process.env.DYNAMODB_SESSIONS_TABLE || 'FairStay-Sessions',
    IMAGES: process.env.DYNAMODB_IMAGES_TABLE || 'FairStay-Images',
    SURVEY_RESPONSES: process.env.DYNAMODB_SURVEY_TABLE || 'FairStay-SurveyResponses',
};
// DynamoDB 테이블 생성 (로컬 개발용)
const createTablesIfNotExists = async () => {
    const existingTables = await aws_1.dynamoDB.listTables().promise();
    const tableNames = existingTables.TableNames || [];
    // Sessions 테이블
    if (!tableNames.includes(exports.TABLES.SESSIONS)) {
        await aws_1.dynamoDB.createTable({
            TableName: exports.TABLES.SESSIONS,
            KeySchema: [
                { AttributeName: 'sessionId', KeyType: 'HASH' },
            ],
            AttributeDefinitions: [
                { AttributeName: 'sessionId', AttributeType: 'S' },
            ],
            BillingMode: 'PAY_PER_REQUEST',
        }).promise();
        console.log(`DynamoDB Table Created: ${exports.TABLES.SESSIONS}`);
    }
    // Images 테이블
    if (!tableNames.includes(exports.TABLES.IMAGES)) {
        await aws_1.dynamoDB.createTable({
            TableName: exports.TABLES.IMAGES,
            KeySchema: [
                { AttributeName: 'imageId', KeyType: 'HASH' },
            ],
            AttributeDefinitions: [
                { AttributeName: 'imageId', AttributeType: 'S' },
                { AttributeName: 'sessionId', AttributeType: 'S' },
            ],
            GlobalSecondaryIndexes: [
                {
                    IndexName: 'SessionIdIndex',
                    KeySchema: [
                        { AttributeName: 'sessionId', KeyType: 'HASH' },
                    ],
                    Projection: {
                        ProjectionType: 'ALL',
                    },
                },
            ],
            BillingMode: 'PAY_PER_REQUEST',
        }).promise();
        console.log(`DynamoDB Table Created: ${exports.TABLES.IMAGES}`);
    }
    // SurveyResponses 테이블
    if (!tableNames.includes(exports.TABLES.SURVEY_RESPONSES)) {
        await aws_1.dynamoDB.createTable({
            TableName: exports.TABLES.SURVEY_RESPONSES,
            KeySchema: [
                { AttributeName: 'responseId', KeyType: 'HASH' },
            ],
            AttributeDefinitions: [
                { AttributeName: 'responseId', AttributeType: 'S' },
                { AttributeName: 'sessionId', AttributeType: 'S' },
            ],
            GlobalSecondaryIndexes: [
                {
                    IndexName: 'SessionIdIndex',
                    KeySchema: [
                        { AttributeName: 'sessionId', KeyType: 'HASH' },
                    ],
                    Projection: {
                        ProjectionType: 'ALL',
                    },
                },
            ],
            BillingMode: 'PAY_PER_REQUEST',
        }).promise();
        console.log(`DynamoDB Table Created: ${exports.TABLES.SURVEY_RESPONSES}`);
    }
};
exports.createTablesIfNotExists = createTablesIfNotExists;
// DynamoDB 연결 확인
const connectDB = async () => {
    try {
        // DynamoDB 연결 테스트
        await aws_1.dynamoDB.listTables().promise();
        console.log('DynamoDB Connected Successfully');
        // 로컬 환경에서만 테이블 자동 생성
        if (process.env.NODE_ENV === 'development' || process.env.CREATE_TABLES === 'true') {
            await (0, exports.createTablesIfNotExists)();
        }
    }
    catch (error) {
        console.error(`DynamoDB Connection Error: ${error.message}`);
        console.log('⚠️  로컬 테스트 모드: DynamoDB 없이 계속 진행합니다.');
        // 로컬 테스트에서는 에러를 던지지 않음
        if (process.env.NODE_ENV === 'production') {
            throw error;
        }
    }
};
exports.connectDB = connectDB;
//# sourceMappingURL=database.js.map