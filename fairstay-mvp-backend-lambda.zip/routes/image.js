"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const Image_1 = __importDefault(require("../models/Image"));
const s3Service_1 = require("../services/s3Service");
const aiService_1 = require("../services/aiService");
const router = (0, express_1.Router)();
// Multer 메모리 스토리지 설정
const upload = (0, multer_1.default)({
    storage: multer_1.default.memoryStorage(),
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB
    },
    fileFilter: (_req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        }
        else {
            cb(new Error('Only image files are allowed'));
        }
    },
});
// 이미지 업로드
router.post('/upload', upload.single('image'), async (req, res) => {
    try {
        const { sessionId } = req.body;
        if (!sessionId) {
            res.status(400).json({
                success: false,
                message: 'Session ID is required',
            });
            return;
        }
        if (!req.file) {
            res.status(400).json({
                success: false,
                message: 'Image file is required',
            });
            return;
        }
        const { imageUrl, s3Key } = await (0, s3Service_1.uploadToS3)(req.file, sessionId);
        const image = await Image_1.default.create({
            sessionId,
            imageUrl,
            s3Key,
            damageAnalysis: {
                status: 'pending',
                damages: [],
            },
        });
        res.status(201).json({
            success: true,
            imageId: image.imageId,
            imageUrl,
            message: 'Image uploaded successfully',
        });
    }
    catch (error) {
        console.error('Image upload error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to upload image',
            error: error.message,
        });
    }
});
// AI 이미지 분석
router.post('/analyze/:imageId', async (req, res) => {
    try {
        const { imageId } = req.params;
        const image = await Image_1.default.findById(imageId);
        if (!image) {
            res.status(404).json({
                success: false,
                message: 'Image not found',
            });
            return;
        }
        if (image.damageAnalysis.status === 'processing' || image.damageAnalysis.status === 'completed') {
            res.json({
                success: true,
                status: image.damageAnalysis.status,
                damages: image.damageAnalysis.damages,
            });
            return;
        }
        await Image_1.default.update(imageId, {
            damageAnalysis: {
                ...image.damageAnalysis,
                status: 'processing',
            },
        });
        try {
            const analysisResult = await (0, aiService_1.analyzeImage)(image.imageUrl);
            // processedImageUrl도 함께 업데이트
            await Image_1.default.update(imageId, {
                processedImageUrl: analysisResult.processedImageUrl,
            });
            const updatedImage = await Image_1.default.updateDamageAnalysis(imageId, {
                status: 'completed',
                damages: analysisResult.damages.map(damage => ({
                    type: damage.type,
                    severity: damage.severity,
                    location: damage.location,
                    confidence: damage.confidence,
                    boundingBox: damage.boundingBox || undefined,
                })),
                processedAt: Date.now(),
            });
            res.json({
                success: true,
                imageId: updatedImage.imageId,
                status: 'completed',
                processedImageUrl: analysisResult.processedImageUrl,
                damages: updatedImage.damageAnalysis.damages,
            });
        }
        catch (aiError) {
            await Image_1.default.updateDamageAnalysis(imageId, {
                status: 'failed',
                damages: [],
            });
            throw aiError;
        }
    }
    catch (error) {
        console.error('Image analysis error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to analyze image',
            error: error.message,
        });
    }
});
// 이미지 정보 조회
router.get('/:imageId', async (req, res) => {
    try {
        const { imageId } = req.params;
        const image = await Image_1.default.findById(imageId);
        if (!image) {
            res.status(404).json({
                success: false,
                message: 'Image not found',
            });
            return;
        }
        res.json({
            success: true,
            image: {
                id: image.imageId,
                sessionId: image.sessionId,
                imageUrl: image.imageUrl,
                processedImageUrl: image.processedImageUrl,
                damageAnalysis: image.damageAnalysis,
                createdAt: image.createdAt,
            },
        });
    }
    catch (error) {
        console.error('Image retrieval error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to retrieve image',
            error: error.message,
        });
    }
});
// 세션의 모든 이미지 조회
router.get('/session/:sessionId', async (req, res) => {
    try {
        const { sessionId } = req.params;
        const images = await Image_1.default.findBySessionId(sessionId);
        res.json({
            success: true,
            count: images.length,
            images: images.map(img => ({
                id: img.imageId,
                sessionId: img.sessionId,
                imageUrl: img.imageUrl,
                damageAnalysis: img.damageAnalysis,
                createdAt: img.createdAt,
            })).sort((a, b) => b.createdAt - a.createdAt), // 최신순 정렬
        });
    }
    catch (error) {
        console.error('Images retrieval error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to retrieve images',
            error: error.message,
        });
    }
});
exports.default = router;
//# sourceMappingURL=image.js.map