"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Session_1 = __importDefault(require("../models/Session"));
const router = (0, express_1.Router)();
// 세션 API 상태 확인
router.get('/', (_req, res) => {
    res.json({
        success: true,
        message: 'Session API is running',
        endpoints: {
            create: 'POST /api/session/create',
            validate: 'GET /api/session/validate/:sessionId',
        },
    });
});
// 새 세션 생성
router.post('/create', async (_req, res) => {
    try {
        const session = await Session_1.default.create();
        res.status(201).json({
            success: true,
            sessionId: session.sessionId,
            message: 'Session created successfully',
        });
    }
    catch (error) {
        console.error('Session creation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to create session',
            error: error.message,
        });
    }
});
// 세션 검증
router.get('/validate/:sessionId', async (req, res) => {
    try {
        const { sessionId } = req.params;
        const session = await Session_1.default.findBySessionId(sessionId);
        if (!session) {
            res.status(404).json({
                success: false,
                message: 'Session not found',
            });
            return;
        }
        await Session_1.default.updateLastActivity(sessionId);
        res.json({
            success: true,
            sessionId: session.sessionId,
            createdAt: session.createdAt,
        });
    }
    catch (error) {
        console.error('Session validation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to validate session',
            error: error.message,
        });
    }
});
exports.default = router;
//# sourceMappingURL=session.js.map