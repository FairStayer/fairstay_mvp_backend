declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=share.d.ts.map