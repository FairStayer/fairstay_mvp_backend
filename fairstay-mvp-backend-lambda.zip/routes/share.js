"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const Image_1 = __importDefault(require("../models/Image"));
const pdfService_1 = require("../services/pdfService");
const router = (0, express_1.Router)();
// PDF 생성
router.post('/generate/:imageId', async (req, res) => {
    try {
        const { imageId } = req.params;
        const image = await Image_1.default.findById(imageId);
        if (!image) {
            res.status(404).json({
                success: false,
                message: 'Image not found',
            });
            return;
        }
        if (image.damageAnalysis.status !== 'completed') {
            res.status(400).json({
                success: false,
                message: 'Image analysis not completed yet',
            });
            return;
        }
        const pdfBuffer = await (0, pdfService_1.generatePDF)(image);
        const pdfBase64 = pdfBuffer.toString('base64');
        res.json({
            success: true,
            pdf: pdfBase64,
            filename: `damage_report_${imageId}.pdf`,
        });
    }
    catch (error) {
        console.error('PDF generation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate PDF',
            error: error.message,
        });
    }
});
// 카카오톡 공유용 메타데이터 생성
router.post('/kakao-share/:imageId', async (req, res) => {
    try {
        const { imageId } = req.params;
        const image = await Image_1.default.findById(imageId);
        if (!image) {
            res.status(404).json({
                success: false,
                message: 'Image not found',
            });
            return;
        }
        if (image.damageAnalysis.status !== 'completed') {
            res.status(400).json({
                success: false,
                message: 'Image analysis not completed yet',
            });
            return;
        }
        const shareData = {
            title: '부동산 손상 리포트',
            description: `총 ${image.damageAnalysis.damages.length}개의 손상이 감지되었습니다.`,
            imageUrl: image.imageUrl,
            link: {
                webUrl: `${process.env.WEB_URL || 'https://fairstay.app'}/report/${imageId}`,
                mobileWebUrl: `${process.env.WEB_URL || 'https://fairstay.app'}/report/${imageId}`,
            },
        };
        res.json({
            success: true,
            shareData,
        });
    }
    catch (error) {
        console.error('Kakao share data generation error:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate share data',
            error: error.message,
        });
    }
});
exports.default = router;
//# sourceMappingURL=share.js.map