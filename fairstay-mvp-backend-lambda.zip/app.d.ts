import { Application } from 'express';
declare const app: Application;
export default app;
//# sourceMappingURL=app.d.ts.map