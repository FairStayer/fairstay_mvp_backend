"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_1 = require("../config/aws");
const database_1 = require("../config/database");
const uuid_1 = require("uuid");
class ImageModel {
    constructor() {
        this.tableName = database_1.TABLES.IMAGES;
    }
    async create(data) {
        const image = {
            imageId: (0, uuid_1.v4)(),
            ...data,
            createdAt: Date.now(),
        };
        await aws_1.documentClient.put({
            TableName: this.tableName,
            Item: image,
        }).promise();
        return image;
    }
    async findById(imageId) {
        const result = await aws_1.documentClient.get({
            TableName: this.tableName,
            Key: { imageId },
        }).promise();
        return result.Item || null;
    }
    async findBySessionId(sessionId) {
        const result = await aws_1.documentClient.query({
            TableName: this.tableName,
            IndexName: 'SessionIdIndex',
            KeyConditionExpression: 'sessionId = :sessionId',
            ExpressionAttributeValues: {
                ':sessionId': sessionId,
            },
        }).promise();
        return result.Items || [];
    }
    async update(imageId, updates) {
        const updateExpressions = [];
        const expressionAttributeNames = {};
        const expressionAttributeValues = {};
        Object.entries(updates).forEach(([key, value], index) => {
            if (key !== 'imageId' && value !== undefined) {
                const attrName = `#attr${index}`;
                const attrValue = `:val${index}`;
                updateExpressions.push(`${attrName} = ${attrValue}`);
                expressionAttributeNames[attrName] = key;
                expressionAttributeValues[attrValue] = value;
            }
        });
        if (updateExpressions.length === 0) {
            return await this.findById(imageId);
        }
        const result = await aws_1.documentClient.update({
            TableName: this.tableName,
            Key: { imageId },
            UpdateExpression: `SET ${updateExpressions.join(', ')}`,
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: expressionAttributeValues,
            ReturnValues: 'ALL_NEW',
        }).promise();
        return result.Attributes || null;
    }
    async updateDamageAnalysis(imageId, damageAnalysis) {
        const result = await aws_1.documentClient.update({
            TableName: this.tableName,
            Key: { imageId },
            UpdateExpression: 'SET damageAnalysis = :damageAnalysis',
            ExpressionAttributeValues: {
                ':damageAnalysis': damageAnalysis,
            },
            ReturnValues: 'ALL_NEW',
        }).promise();
        return result.Attributes || null;
    }
    async delete(imageId) {
        await aws_1.documentClient.delete({
            TableName: this.tableName,
            Key: { imageId },
        }).promise();
    }
}
exports.default = new ImageModel();
//# sourceMappingURL=Image.js.map