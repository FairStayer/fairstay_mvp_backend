export interface IBoundingBox {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface IDamage {
    type: string;
    severity: string;
    location: string;
    confidence: number;
    boundingBox?: IBoundingBox;
}
export interface IDamageAnalysis {
    status: 'pending' | 'processing' | 'completed' | 'failed';
    damages: IDamage[];
    processedAt?: number;
}
export interface IImage {
    imageId: string;
    sessionId: string;
    imageUrl: string;
    s3Key: string;
    processedImageUrl?: string;
    damageAnalysis: IDamageAnalysis;
    createdAt: number;
}
declare class ImageModel {
    private tableName;
    create(data: Omit<IImage, 'imageId' | 'createdAt'>): Promise<IImage>;
    findById(imageId: string): Promise<IImage | null>;
    findBySessionId(sessionId: string): Promise<IImage[]>;
    update(imageId: string, updates: Partial<IImage>): Promise<IImage | null>;
    updateDamageAnalysis(imageId: string, damageAnalysis: IDamageAnalysis): Promise<IImage | null>;
    delete(imageId: string): Promise<void>;
}
declare const _default: ImageModel;
export default _default;
//# sourceMappingURL=Image.d.ts.map