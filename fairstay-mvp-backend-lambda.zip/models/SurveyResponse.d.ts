export type SurveyResponseType = 'very_helpful' | 'helpful' | 'neutral' | 'not_helpful' | 'not_needed';
export interface ISurveyResponse {
    responseId: string;
    sessionId: string;
    response: SurveyResponseType;
    additionalComments?: string;
    createdAt: number;
}
declare class SurveyResponseModel {
    private tableName;
    create(data: Omit<ISurveyResponse, 'responseId' | 'createdAt'>): Promise<ISurveyResponse>;
    findById(responseId: string): Promise<ISurveyResponse | null>;
    findAll(): Promise<ISurveyResponse[]>;
    findBySessionId(sessionId: string): Promise<ISurveyResponse[]>;
    delete(responseId: string): Promise<void>;
}
declare const _default: SurveyResponseModel;
export default _default;
//# sourceMappingURL=SurveyResponse.d.ts.map