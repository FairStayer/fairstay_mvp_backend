export interface ISession {
    sessionId: string;
    createdAt: number;
    lastActivity: number;
    ttl?: number;
}
declare class SessionModel {
    private tableName;
    create(sessionId?: string): Promise<ISession>;
    findBySessionId(sessionId: string): Promise<ISession | null>;
    updateLastActivity(sessionId: string): Promise<ISession | null>;
    delete(sessionId: string): Promise<void>;
}
declare const _default: SessionModel;
export default _default;
//# sourceMappingURL=Session.d.ts.map