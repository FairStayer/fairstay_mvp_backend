"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_1 = require("../config/aws");
const database_1 = require("../config/database");
const uuid_1 = require("uuid");
class SessionModel {
    constructor() {
        this.tableName = database_1.TABLES.SESSIONS;
    }
    async create(sessionId) {
        const now = Date.now();
        const session = {
            sessionId: sessionId || (0, uuid_1.v4)(),
            createdAt: now,
            lastActivity: now,
            ttl: Math.floor(now / 1000) + 86400, // 24시간 TTL
        };
        await aws_1.documentClient.put({
            TableName: this.tableName,
            Item: session,
        }).promise();
        return session;
    }
    async findBySessionId(sessionId) {
        const result = await aws_1.documentClient.get({
            TableName: this.tableName,
            Key: { sessionId },
        }).promise();
        return result.Item || null;
    }
    async updateLastActivity(sessionId) {
        const now = Date.now();
        const result = await aws_1.documentClient.update({
            TableName: this.tableName,
            Key: { sessionId },
            UpdateExpression: 'SET lastActivity = :now, #ttl = :ttl',
            ExpressionAttributeNames: {
                '#ttl': 'ttl',
            },
            ExpressionAttributeValues: {
                ':now': now,
                ':ttl': Math.floor(now / 1000) + 86400,
            },
            ReturnValues: 'ALL_NEW',
        }).promise();
        return result.Attributes || null;
    }
    async delete(sessionId) {
        await aws_1.documentClient.delete({
            TableName: this.tableName,
            Key: { sessionId },
        }).promise();
    }
}
exports.default = new SessionModel();
//# sourceMappingURL=Session.js.map