"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_1 = require("../config/aws");
const database_1 = require("../config/database");
const uuid_1 = require("uuid");
class SurveyResponseModel {
    constructor() {
        this.tableName = database_1.TABLES.SURVEY_RESPONSES;
    }
    async create(data) {
        const surveyResponse = {
            responseId: (0, uuid_1.v4)(),
            ...data,
            createdAt: Date.now(),
        };
        await aws_1.documentClient.put({
            TableName: this.tableName,
            Item: surveyResponse,
        }).promise();
        return surveyResponse;
    }
    async findById(responseId) {
        const result = await aws_1.documentClient.get({
            TableName: this.tableName,
            Key: { responseId },
        }).promise();
        return result.Item || null;
    }
    async findAll() {
        const result = await aws_1.documentClient.scan({
            TableName: this.tableName,
        }).promise();
        return result.Items || [];
    }
    async findBySessionId(sessionId) {
        const result = await aws_1.documentClient.query({
            TableName: this.tableName,
            IndexName: 'SessionIdIndex',
            KeyConditionExpression: 'sessionId = :sessionId',
            ExpressionAttributeValues: {
                ':sessionId': sessionId,
            },
        }).promise();
        return result.Items || [];
    }
    async delete(responseId) {
        await aws_1.documentClient.delete({
            TableName: this.tableName,
            Key: { responseId },
        }).promise();
    }
}
exports.default = new SurveyResponseModel();
//# sourceMappingURL=SurveyResponse.js.map