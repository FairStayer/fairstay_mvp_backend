/**
 * FairStay MVP Backend - AWS Lambda Handler
 *
 * API Gateway 설정:
 * - 엔드포인트: https://y0uhk6afg9.execute-api.ap-northeast-2.amazonaws.com/default/fairstay-mvp-backend
 * - 리소스 경로: /fairstay-mvp-backend
 * - 메서드: ANY
 *
 * 환경 변수 필수 설정:
 * - S3_BUCKET_NAME: S3 버킷 이름
 * - DYNAMODB_TABLE_PREFIX: DynamoDB 테이블 접두사
 * - AI_SERVER_URL: AI 서버 URL
 * - AWS_REGION: ap-northeast-2 (자동 설정됨)
 */
/**
 * Lambda Handler
 * API Gateway HTTP API와 통합
 */
export declare const handler: (event: any, context: any) => Promise<any>;
//# sourceMappingURL=index.d.ts.map