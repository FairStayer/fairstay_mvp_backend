export interface BoundingBox {
    x: number;
    y: number;
    width: number;
    height: number;
}
export interface AIDamage {
    type: string;
    severity: string;
    location: string;
    confidence: number;
    bounding_box?: BoundingBox;
}
export interface AIServerResponse {
    image_url: string;
}
export interface AnalysisResult {
    processedImageUrl?: string;
    damages: Array<{
        type: string;
        severity: string;
        location: string;
        confidence: number;
        boundingBox: BoundingBox | null;
    }>;
}
/**
 * AI 서버에 이미지 분석 요청
 * AI 서버는 /detect-crack 엔드포인트를 사용하고 multipart/form-data로 이미지 파일을 받음
 */
export declare const analyzeImage: (imageUrl: string) => Promise<AnalysisResult>;
/**
 * AI 서버 상태 확인
 */
export declare const checkAIServerHealth: () => Promise<boolean>;
//# sourceMappingURL=aiService.d.ts.map