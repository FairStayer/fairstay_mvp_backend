"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.s3 = exports.getPresignedUrl = exports.deleteFromS3 = exports.uploadToS3 = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const uuid_1 = require("uuid");
// AWS SDK 설정
aws_sdk_1.default.config.update({
    region: process.env.AWS_REGION || 'ap-northeast-2',
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});
const s3 = new aws_sdk_1.default.S3({
    apiVersion: '2006-03-01',
    region: process.env.S3_REGION || process.env.AWS_REGION,
});
exports.s3 = s3;
/**
 * S3에 이미지 업로드
 */
const uploadToS3 = async (file, sessionId) => {
    try {
        const fileExtension = file.originalname.split('.').pop();
        const fileName = `${sessionId}/${(0, uuid_1.v4)()}.${fileExtension}`;
        const params = {
            Bucket: process.env.S3_BUCKET_NAME,
            Key: fileName,
            Body: file.buffer,
            ContentType: file.mimetype,
            ACL: 'public-read',
        };
        const result = await s3.upload(params).promise();
        return {
            imageUrl: result.Location,
            s3Key: result.Key,
        };
    }
    catch (error) {
        console.error('S3 upload error:', error);
        throw new Error('Failed to upload image to S3');
    }
};
exports.uploadToS3 = uploadToS3;
/**
 * S3에서 이미지 삭제
 */
const deleteFromS3 = async (s3Key) => {
    try {
        const params = {
            Bucket: process.env.S3_BUCKET_NAME,
            Key: s3Key,
        };
        await s3.deleteObject(params).promise();
        return true;
    }
    catch (error) {
        console.error('S3 delete error:', error);
        throw new Error('Failed to delete image from S3');
    }
};
exports.deleteFromS3 = deleteFromS3;
/**
 * S3에서 이미지 가져오기 (Presigned URL)
 */
const getPresignedUrl = async (s3Key, expiresIn = 3600) => {
    try {
        const params = {
            Bucket: process.env.S3_BUCKET_NAME,
            Key: s3Key,
        };
        const url = await s3.getSignedUrlPromise('getObject', {
            ...params,
            Expires: expiresIn,
        });
        return url;
    }
    catch (error) {
        console.error('S3 presigned URL error:', error);
        throw new Error('Failed to generate presigned URL');
    }
};
exports.getPresignedUrl = getPresignedUrl;
//# sourceMappingURL=s3Service.js.map