import AWS from 'aws-sdk';
declare const s3: AWS.S3;
export interface UploadResult {
    imageUrl: string;
    s3Key: string;
}
export interface FileUpload {
    originalname: string;
    buffer: Buffer;
    mimetype: string;
}
/**
 * S3에 이미지 업로드
 */
export declare const uploadToS3: (file: FileUpload, sessionId: string) => Promise<UploadResult>;
/**
 * S3에서 이미지 삭제
 */
export declare const deleteFromS3: (s3Key: string) => Promise<boolean>;
/**
 * S3에서 이미지 가져오기 (Presigned URL)
 */
export declare const getPresignedUrl: (s3Key: string, expiresIn?: number) => Promise<string>;
/**
 * S3 업로드용 Presigned URL 생성
 */
export declare const generateUploadPresignedUrl: (sessionId: string, filename: string, contentType: string, expiresIn?: number) => Promise<{
    uploadUrl: string;
    s3Key: string;
    imageUrl: string;
}>;
export { s3 };
//# sourceMappingURL=s3Service.d.ts.map