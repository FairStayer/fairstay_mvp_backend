import { IImage } from '../models/Image';
/**
 * 손상 리포트 PDF 생성
 */
export declare const generatePDF: (image: IImage) => Promise<Buffer>;
//# sourceMappingURL=pdfService.d.ts.map