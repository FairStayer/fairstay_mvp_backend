"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
// 환경변수 로드
dotenv_1.default.config();
const app = (0, express_1.default)();
// Middleware
app.use((0, cors_1.default)());
app.use(express_1.default.json());
app.use(express_1.default.urlencoded({ extended: true }));
// Health check
app.get('/', (_req, res) => {
    res.json({
        success: true,
        message: 'FairStay MVP Backend API',
        version: '1.0.0',
    });
});
app.get('/health', (_req, res) => {
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString(),
    });
});
// Routes
const session_1 = __importDefault(require("./routes/session"));
const image_1 = __importDefault(require("./routes/image"));
const share_1 = __importDefault(require("./routes/share"));
const survey_1 = __importDefault(require("./routes/survey"));
app.use('/api/session', session_1.default);
app.use('/api/image', image_1.default);
app.use('/api/share', share_1.default);
app.use('/api/survey', survey_1.default);
// Error handling middleware
app.use((err, _req, res, _next) => {
    console.error('Error:', err);
    if (err.message === 'Only image files are allowed') {
        res.status(400).json({
            success: false,
            message: err.message,
        });
        return;
    }
    res.status(500).json({
        success: false,
        message: 'Internal server error',
        error: process.env.NODE_ENV === 'development' ? err.message : undefined,
    });
});
// 404 handler
app.use((_req, res) => {
    res.status(404).json({
        success: false,
        message: 'Route not found',
    });
});
exports.default = app;
//# sourceMappingURL=app.js.map